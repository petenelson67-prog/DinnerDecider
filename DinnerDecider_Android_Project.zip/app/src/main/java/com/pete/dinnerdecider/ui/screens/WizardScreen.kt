package com.pete.dinnerdecider.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pete.dinnerdecider.viewmodel.DinnerViewModel

@Composable
fun WizardScreen(vm: DinnerViewModel, goPantry: () -> Unit, goPhoto: () -> Unit, onDone: () -> Unit) {
    var ketoStrict by remember { mutableStateOf(vm.ketoStrict) }
    var cuisine by remember { mutableStateOf(vm.cuisine) }
    var cookTime by remember { mutableStateOf(vm.maxCookMinutes.toFloat()) }
    var travel by remember { mutableStateOf(vm.travelWillingness.toFloat()) }

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Tonight: Stay strict keto?", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(selected = ketoStrict, onClick = { ketoStrict = true }, label = { Text("Strict") })
            FilterChip(selected = !ketoStrict, onClick = { ketoStrict = false }, label = { Text("Open to break") })
        }

        Text("Cuisine preference", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value = cuisine, onValueChange = { cuisine = it }, label = { Text("Cuisine (e.g., Mexican)") })

        Text("Max cook time: ${cookTime.toInt()} min")
        Slider(value = cookTime, onValueChange = { cookTime = it }, valueRange = 10f..90f)

        Text("Travel willingness: ${travel.toInt()}/10")
        Slider(value = travel, onValueChange = { travel = it }, valueRange = 1f..10f)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = goPantry) { Text("Edit Pantry") }
            Button(onClick = goPhoto) { Text("Scan Photo") }
            Spacer(Modifier.weight(1f))
            Button(onClick = {
                vm.updateWizard(ketoStrict, cuisine, cookTime.toInt(), travel.toInt())
                onDone()
            }, modifier = Modifier.align(Alignment.CenterVertically)) { Text("See suggestions") }
        }
    }
}
