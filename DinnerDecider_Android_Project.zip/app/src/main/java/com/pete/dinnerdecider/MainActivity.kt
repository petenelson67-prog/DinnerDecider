package com.pete.dinnerdecider

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pete.dinnerdecider.ui.AppTheme
import com.pete.dinnerdecider.ui.screens.*
import com.pete.dinnerdecider.viewmodel.DinnerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    AppTheme {
        val nav = rememberNavController()
        val vm: DinnerViewModel = viewModel()
        Scaffold { padding ->
            NavHost(navController = nav, startDestination = "wizard") {
                composable("wizard") { WizardScreen(vm = vm, goPantry = { nav.navigate("pantry") }, goPhoto = { nav.navigate("photo") }, onDone = { nav.navigate("suggestions") }) }
                composable("pantry") { PantryScreen(vm = vm, onBack = { nav.popBackStack() }) }
                composable("photo") { PhotoScanScreen(vm = vm, onBack = { nav.popBackStack() }) }
                composable("suggestions") { SuggestionsScreen(vm = vm, onBack = { nav.popBackStack() }) }
            }
        }
    }
}
