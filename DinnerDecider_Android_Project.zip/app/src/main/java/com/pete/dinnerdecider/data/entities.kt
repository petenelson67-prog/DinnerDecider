package com.pete.dinnerdecider.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pantry_items")
data class PantryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val qty: Int = 1
)

@Entity(tableName = "favorites")
data class FavoriteMeal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val keto: Boolean,
    val cuisine: String
)
