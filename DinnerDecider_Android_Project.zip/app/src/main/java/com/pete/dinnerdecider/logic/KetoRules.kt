package com.pete.dinnerdecider.logic

object KetoRules {
    private val nonKetoKeywords = setOf(
        "tortilla", "rice", "beans", "bread", "sugar", "pasta", "corn", "potato", "tortillas"
    )

    fun isKetoFriendly(ingredients: List<String>): Boolean =
        ingredients.none { ing -> nonKetoKeywords.any { key -> ing.contains(key, ignoreCase = true) } }
}
