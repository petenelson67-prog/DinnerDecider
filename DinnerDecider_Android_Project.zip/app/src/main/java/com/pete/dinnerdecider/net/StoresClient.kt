package com.pete.dinnerdecider.net

import okhttp3.OkHttpClient
import okhttp3.Request

class StoresClient {
    private val http = OkHttpClient()
    fun weeklyDeals(storeUrl: String): List<String> {
        if (storeUrl.isBlank()) return emptyList()
        val req = Request.Builder().url(storeUrl).build()
        http.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            val regex = Regex("\$\s?\d{1,3}(?:\.\d{2})?|\b\d{1,2}% off\b|buy \d+ get \d+", RegexOption.IGNORE_CASE)
            return regex.findAll(text).map { it.value.trim() }.distinct().take(50).toList()
        }
    }
}
