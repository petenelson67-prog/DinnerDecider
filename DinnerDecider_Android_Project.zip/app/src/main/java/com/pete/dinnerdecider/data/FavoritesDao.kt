package com.pete.dinnerdecider.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoritesDao {
    @Query("SELECT * FROM favorites ORDER BY title")
    fun all(): Flow<List<FavoriteMeal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: FavoriteMeal)

    @Delete
    suspend fun delete(item: FavoriteMeal)
}
