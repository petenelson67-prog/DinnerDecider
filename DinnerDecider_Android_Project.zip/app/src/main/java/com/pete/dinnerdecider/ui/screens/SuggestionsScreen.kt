package com.pete.dinnerdecider.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.launch
import com.pete.dinnerdecider.logic.*
import com.pete.dinnerdecider.viewmodel.DinnerViewModel

@Composable
fun SuggestionsScreen(vm: DinnerViewModel, onBack: () -> Unit) {
    val pantry by vm.pantry.collectAsState(emptyList())
    val scope = rememberCoroutineScope()

    var area by remember { mutableStateOf("Treasure Island, FL") }
    var dealsUrl by remember { mutableStateOf("") }
    var onlineRestaurants by remember { mutableStateOf<List<String>>(emptyList()) }
    var deals by remember { mutableStateOf<List<String>>(emptyList()) }

    val q = Query(
        ketoStrict = vm.ketoStrict,
        cuisine = vm.cuisine.ifBlank { null },
        pantry = pantry.map { it.name },
        maxMinutes = vm.maxCookMinutes,
        travelWillingness = vm.travelWillingness
    )
    var suggestions by remember { mutableStateOf(SuggestionEngine.suggest(q)) }

    fun reroll() {
        suggestions = SuggestionEngine.suggest(q.copy(travelWillingness = (1..10).random()))
    }

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Tonight’s picks", style = MaterialTheme.typography.titleLarge)
        suggestions.forEach { s ->
            ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text(s.title, style = MaterialTheme.typography.titleMedium)
                Text(s.reason, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { scope.launch { vm.saveFavorite(s) } }) { Text("Save Favorite") }
                }
            }}
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { reroll() }) { Text("Reroll") }
            Button(onClick = onBack) { Text("Back") }
        }

        Divider()
        Text("Online lookups (optional)", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value = area, onValueChange = { area = it }, label = { Text("Area for restaurants (city/neighborhood)") })
        Button(enabled = vm.hasPlacesKey, onClick = {
            scope.launch { onlineRestaurants = vm.searchRestaurants(area) }
        }) { Text(if (vm.hasPlacesKey) "Find nearby restaurants" else "Add PLACES_API_KEY to enable") }
        onlineRestaurants.takeIf { it.isNotEmpty() }?.let { list ->
            Text("Nearby restaurants:")
            list.forEach { Text("• $it") }
        }

        OutlinedTextField(value = dealsUrl, onValueChange = { dealsUrl = it }, label = { Text("Store weekly ad URL (optional)") })
        Button(onClick = { scope.launch { deals = vm.fetchDeals(dealsUrl) } }, enabled = dealsUrl.isNotBlank()) { Text("Fetch deals") }
        deals.takeIf { it.isNotEmpty() }?.let { lines ->
            Text("Deals (extracted):")
            lines.take(8).forEach { Text("• $it") }
        }
    }
}
