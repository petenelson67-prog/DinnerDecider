package com.pete.dinnerdecider.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import com.pete.dinnerdecider.viewmodel.DinnerViewModel
import kotlinx.coroutines.launch

@Composable
fun PhotoScanScreen(vm: DinnerViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var labels by remember { mutableStateOf<List<String>>(emptyList()) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bmp = vm.loadBitmap(uri)
                bitmap = bmp
                labels = if (bmp != null) vm.labelBitmap(bmp) else emptyList()
            }
        }
    }

    val takePreview = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) {
            bitmap = bmp
            scope.launch { labels = vm.labelBitmap(bmp) }
        }
    }

    val selected = remember { mutableStateMapOf<String, Boolean>() }
    labels.forEach { if (selected[it] == null) selected[it] = true }

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Scan fridge/pantry photo (offline ML)", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { pickImage.launch("image/*") }) { Text("Pick Photo") }
            Button(onClick = { takePreview.launch(null) }) { Text("Take Photo") }
        }
        bitmap?.let { Image(it.asImageBitmap(), contentDescription = null, modifier = Modifier.height(200.dp)) }
        if (labels.isNotEmpty()) {
            Text("Detected items (toggle to include):")
            LazyColumn(Modifier.heightIn(max = 200.dp)) {
                items(labels) { l ->
                    val checked = selected[l] ?: false
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(l)
                        Switch(checked = checked, onCheckedChange = { selected[l] = it })
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { scope.launch { vm.addPantryMany(selected.filterValues { it }.keys.toList()) } }) { Text("Add to Pantry") }
                Button(onClick = { bitmap = null; labels = emptyList(); selected.clear() }) { Text("Reset") }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onBack) { Text("Back") }
    }
}
