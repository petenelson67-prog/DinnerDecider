package com.pete.dinnerdecider.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.pete.dinnerdecider.data.ReposProvider
import com.pete.dinnerdecider.data.PantryItem
import com.pete.dinnerdecider.logic.MealSuggestion
import com.pete.dinnerdecider.ml.ImageLabeler
import com.pete.dinnerdecider.net.PlacesClient
import com.pete.dinnerdecider.net.StoresClient
import com.pete.dinnerdecider.BuildConfig

class DinnerViewModel(app: Application) : AndroidViewModel(app) {
    var ketoStrict: Boolean = true
        private set
    var cuisine: String = "Mexican"
        private set
    var maxCookMinutes: Int = 30
        private set
    var travelWillingness: Int = 5
        private set

    fun updateWizard(ketoStrict: Boolean, cuisine: String, maxMins: Int, travel: Int) {
        this.ketoStrict = ketoStrict
        this.cuisine = cuisine
        this.maxCookMinutes = maxMins
        this.travelWillingness = travel
    }

    private val pantryRepo = ReposProvider.pantry(app)
    private val favoritesRepo = ReposProvider.favorites(app)

    val pantry = pantryRepo.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val favorites = favoritesRepo.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    suspend fun addPantry(name: String) = pantryRepo.upsert(name)
    suspend fun addPantryMany(names: List<String>) = pantryRepo.upsertMany(names)
    suspend fun removePantry(item: PantryItem) = pantryRepo.delete(item)
    suspend fun clearPantry() = pantryRepo.clear()

    suspend fun saveFavorite(s: MealSuggestion) {
        favoritesRepo.save(s.title, s.keto, cuisine)
    }

    private val labeler = ImageLabeler()

    suspend fun loadBitmap(uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        val ctx = getApplication<Application>()
        val src = ctx.contentResolver.openInputStream(uri) ?: return@withContext null
        val bmp = android.graphics.BitmapFactory.decodeStream(src)
        src.close()
        bmp
    }

    suspend fun labelBitmap(bmp: Bitmap): List<String> = withContext(Dispatchers.Default) {
        labeler.labels(bmp)
            .map { it.lowercase() }
            .map { it.replace("food", "").trim() }
            .filter { it.isNotBlank() }
            .distinct()
    }

    val hasPlacesKey: Boolean get() = BuildConfig.PLACES_API_KEY.isNotBlank()
    private val places by lazy { PlacesClient(BuildConfig.PLACES_API_KEY) }
    private val stores by lazy { StoresClient() }

    suspend fun searchRestaurants(area: String): List<String> = withContext(Dispatchers.IO) {
        places.restaurantsInArea(area, cuisine.ifBlank { "mexican" })
    }

    suspend fun fetchDeals(url: String): List<String> = withContext(Dispatchers.IO) {
        stores.weeklyDeals(url)
    }
}
