package com.pete.dinnerdecider.data

class PantryRepo(private val dao: PantryDao) {
    fun all() = dao.all()
    suspend fun upsert(name: String, qty: Int = 1) = dao.upsert(PantryItem(name = name, qty = qty))
    suspend fun upsertMany(names: List<String>) { names.forEach { dao.upsert(PantryItem(name = it, qty = 1)) } }
    suspend fun delete(item: PantryItem) = dao.delete(item)
    suspend fun clear() = dao.clear()
}

class FavoritesRepo(private val dao: FavoritesDao) {
    fun all() = dao.all()
    suspend fun save(title: String, keto: Boolean, cuisine: String) =
        dao.upsert(FavoriteMeal(title = title, keto = keto, cuisine = cuisine))
    suspend fun delete(item: FavoriteMeal) = dao.delete(item)
}

object ReposProvider {
    fun pantry(context: android.content.Context) = PantryRepo(AppDatabase.get(context).pantry())
    fun favorites(context: android.content.Context) = FavoritesRepo(AppDatabase.get(context).favorites())
}
