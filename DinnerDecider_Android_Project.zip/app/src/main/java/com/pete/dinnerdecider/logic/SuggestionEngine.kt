package com.pete.dinnerdecider.logic

import kotlin.math.max

data class Query(
    val ketoStrict: Boolean,
    val cuisine: String?,
    val pantry: List<String>,
    val maxMinutes: Int,
    val travelWillingness: Int // 1..10
)

data class MealSuggestion(val title: String, val reason: String, val keto: Boolean)

object SuggestionEngine {
    private val ketoMeals = listOf(
        "Steak with garlic butter",
        "Chicken fajita bowl (no tortilla)",
        "Bunless bacon cheeseburgers",
        "Shrimp zoodles alfredo",
        "Taco salad (no chips)"
    )

    private val nonKetoMeals = listOf(
        "Chicken tacos",
        "Beef burritos",
        "Spaghetti bolognese",
        "Sushi rolls",
        "VIP Treasure Island night out"
    )

    fun suggest(q: Query): List<MealSuggestion> {
        val pool = if (q.ketoStrict) ketoMeals else ketoMeals + nonKetoMeals
        val weighted = pool.map { title ->
            var score = 0
            val titleLower = title.lowercase()

            if (q.cuisine != null) {
                if (q.cuisine.equals("mexican", true) &&
                    (titleLower.contains("taco") || titleLower.contains("fajita") || titleLower.contains("vip"))) {
                    score += 30
                }
            }

            if (q.pantry.any { p -> titleLower.contains(p.lowercase()) }) score += 15

            if (q.maxMinutes <= 30 && (titleLower.contains("salad") || titleLower.contains("bowl"))) score += 10

            if (q.travelWillingness >= 7 && titleLower.contains("vip")) score += 40

            val keto = titleLower.contains("salad") || titleLower.contains("bowl") || titleLower.contains("bun") ||
                    titleLower.contains("zoodles") || titleLower.contains("steak")
            if (q.ketoStrict && !keto) score -= 100

            score = max(score, 0)
            val reason = buildString {
                append("Score " + score + ": ")
                if (q.cuisine?.equals("mexican", true) == true) append("craving Mexican; ")
                if (q.pantry.isNotEmpty()) append("uses pantry items; ")
                append("time ≤ ${q.maxMinutes} min; travel ${q.travelWillingness}/10")
            }
            MealSuggestion(title = title, reason = reason, keto = keto)
        }
        return weighted.sortedByDescending { it.reason.length }.take(5)
    }
}
