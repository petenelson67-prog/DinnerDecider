package com.pete.dinnerdecider.net

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class PlacesClient(private val apiKey: String) {
    private val http = OkHttpClient()

    fun restaurantsInArea(area: String, cuisine: String = "mexican"): List<String> {
        if (apiKey.isBlank()) return emptyList()
        val query = "${cuisine}+restaurant+in+" + area.replace(" ", "+")
        val url = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=${query}&key=${apiKey}"
        val req = Request.Builder().url(url).build()
        http.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (body.isBlank()) return emptyList()
            val json = JSONObject(body)
            val results = json.optJSONArray("results") ?: return emptyList()
            return (0 until results.length()).mapNotNull { i ->
                val o = results.optJSONObject(i) ?: return@mapNotNull null
                val name = o.optString("name")
                val addr = o.optString("formatted_address")
                if (name.isNotBlank()) "$name — $addr" else null
            }
        }
    }
}
