package com.pete.dinnerdecider.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.launch
import com.pete.dinnerdecider.viewmodel.DinnerViewModel
import com.pete.dinnerdecider.data.PantryItem

@Composable
fun PantryScreen(vm: DinnerViewModel, onBack: () -> Unit) {
    val pantry by vm.pantry.collectAsState(emptyList())
    var input by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Pantry items (persisted)", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("Add ingredient") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done, keyboardType = KeyboardType.Text)
            )
            Button(onClick = {
                val name = input.trim()
                if (name.isNotEmpty()) { scope.launch { vm.addPantry(name) }; input = "" }
            }) { Text("Add") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f, fill = false)) {
            items(pantry) { item ->
                ElevatedCard { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(item.name)
                    TextButton(onClick = { scope.launch { vm.removePantry(item) } }) { Text("Remove") }
                }}
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { scope.launch { vm.clearPantry() } }) { Text("Clear") }
            Spacer(Modifier.weight(1f))
            Button(onClick = onBack) { Text("Back") }
        }
    }
}
