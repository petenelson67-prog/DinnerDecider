rootProject.name = "DinnerDecider"
include(":app")
